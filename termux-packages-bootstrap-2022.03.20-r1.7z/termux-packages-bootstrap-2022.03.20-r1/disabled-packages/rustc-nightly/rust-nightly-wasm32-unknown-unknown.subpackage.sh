TERMUX_SUBPKG_DESCRIPTION="rust std for wasm32-unknown-unknown target"
TERMUX_SUBPKG_PLATFORM_INDEPENDENT=true
TERMUX_SUBPKG_INCLUDE="opt/rust-nightly/lib/rustlib/wasm32-unknown-unknown"
