TERMUX_PKG_HOMEPAGE=https://packages.debian.org/source/sid/deborphan
TERMUX_PKG_DESCRIPTION="Program that can find unused packages"
TERMUX_PKG_VERSION=1.7.28.8-0.3
TERMUX_PKG_SRCURL=http://http.debian.net/debian/pool/main/d/deborphan/deborphan_$TERMUX_PKG_VERSION.tar.gz
TERMUX_PKG_BUILD_IN_SRC=true
TERMUX_PKG_MAINTAINER="Pierre Rudloff @Rudloff"
