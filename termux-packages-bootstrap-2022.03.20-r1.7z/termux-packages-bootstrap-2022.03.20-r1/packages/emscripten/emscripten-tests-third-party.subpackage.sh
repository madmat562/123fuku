TERMUX_SUBPKG_DESCRIPTION="Emscripten third party test suite files"
TERMUX_SUBPKG_PLATFORM_INDEPENDENT=true
TERMUX_SUBPKG_INCLUDE="opt/emscripten/tests/third_party"
