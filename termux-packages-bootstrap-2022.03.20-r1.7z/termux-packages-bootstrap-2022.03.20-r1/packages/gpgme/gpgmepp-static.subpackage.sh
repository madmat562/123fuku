TERMUX_SUBPKG_DESCRIPTION="Static libraries for gpgmepp"
TERMUX_SUBPKG_DEPENDS="gpgmepp"
TERMUX_SUBPKG_INCLUDE="
lib/libgpgmepp.la
lib/libgpgmepp.a
"
