TERMUX_SUBPKG_INCLUDE="bin/ld.gold bin/gold"
TERMUX_SUBPKG_DESCRIPTION="gold linker"
