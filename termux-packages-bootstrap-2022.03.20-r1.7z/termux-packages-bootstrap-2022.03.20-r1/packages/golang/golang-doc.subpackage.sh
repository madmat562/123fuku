TERMUX_SUBPKG_INCLUDE="lib/go/doc"
TERMUX_SUBPKG_DESCRIPTION="Go programming language - documentation"
