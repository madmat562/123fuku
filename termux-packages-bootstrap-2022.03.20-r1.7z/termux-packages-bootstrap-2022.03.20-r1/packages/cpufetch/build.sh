TERMUX_PKG_HOMEPAGE=https://github.com/Dr-Noob/cpufetch
TERMUX_PKG_DESCRIPTION="Simple yet fancy CPU architecture fetching tool"
TERMUX_PKG_LICENSE="MIT"
TERMUX_PKG_MAINTAINER="@ELWAER-M"
TERMUX_PKG_VERSION=1.01
TERMUX_PKG_SRCURL=https://github.com/Dr-Noob/cpufetch/archive/refs/tags/v${TERMUX_PKG_VERSION}.tar.gz
TERMUX_PKG_SHA256=d4fe25adc4d12f5f1dc7a7e70a4ed92e9807b6a1ad0294c563a0250f7bd6aca1
TERMUX_PKG_BUILD_IN_SRC=true
