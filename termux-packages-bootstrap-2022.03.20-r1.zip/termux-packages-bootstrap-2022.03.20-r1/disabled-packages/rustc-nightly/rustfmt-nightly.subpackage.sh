TERMUX_SUBPKG_DESCRIPTION="A tool for formatting Rust code according to style guidelines"
TERMUX_SUBPKG_INCLUDE="opt/rust-nightly/bin/cargo-fmt opt/rust-nightly/bin/rustfmt opt/rust-nightlyshare/doc/rustfmt"
TERMUX_SUBPKG_DEPENDS="rustc-nightly"

