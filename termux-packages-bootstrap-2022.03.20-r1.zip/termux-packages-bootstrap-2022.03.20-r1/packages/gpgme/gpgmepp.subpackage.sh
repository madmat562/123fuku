TERMUX_SUBPKG_DESCRIPTION="Programmatic C++ library interface to GnuPG"
TERMUX_SUBPKG_INCLUDE="
lib/libgpgmepp.so
lib/cmake/Gpgmepp
include/gpgme++
"
